<?php

/* assignment lang */



$lang['member_name'] = "Select member to Assign";
$lang['item'] = "Select Item to Assign";
$lang['add_page'] = "Add Assignment";
$lang['page_form'] = "Assignment form";
$lang['page_list'] = "Assignment list";
$lang['client_placeholder'] = "Search Assignment by name";
$lang['edit_page'] = "Edit Client";
$lang['assignment_management'] = "Assignment Manage";
$lang['dashboard'] = "Dashboard";
$lang['title'] = "Title";
$lang['control_panel'] = "Control panel";

