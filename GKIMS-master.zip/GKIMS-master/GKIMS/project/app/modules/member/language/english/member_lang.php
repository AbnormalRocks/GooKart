<?php

/* member lang */

$lang['member_name'] = "Name";
$lang['member_model_number'] = "Model No.";
$lang['category_id'] = "Category ID";
$lang['member_identification_key'] = "Identification Key";
$lang['member_cost_price'] = "Cost Price";
$lang['member_vendor_id'] = "Vendor ID";
$lang['member_purchase_date'] = "Purchase Date";
$lang['member_location'] = "Location";
$lang['member_quantity'] = "Quantity";
$lang['member_id'] = "ID";
$lang['member_description'] = "Description";
$lang['member_code'] = "Code";
$lang['member_status'] = "Status";
$lang['no_of members'] = "No. of Members";
$lang['add_page'] = "Add Member";
$lang['page_form'] = "Member form";
$lang['page_list'] = "Member list";
$lang['department_placeholder'] = "Search Member by name";
$lang['is_timesheet_required'] = "Is Member timesheet atachment required?";
$lang['edit_page'] = "Edit Member";
$lang['member_management'] = "Member Manager";
$lang['dashboard'] = "Dashboard";
$lang['title'] = "Title";
$lang['member_type'] = "Member Type";
$lang['allowed_hours'] = "Allowed Hours";
$lang['allowed_vacations'] = "Allowed Vacations";
$lang['delete_selected'] = "Delete Selected";
$lang['no_record_found'] = "No Record Found";
$lang['member_model_number'] = "Model No.";
$lang['category_id'] = "Category ID";
$lang['member_identification_code'] = "Identification Code";
$lang['member_cost_price'] = "Cost Price";
$lang['member_vendor_id'] = "Vendor ID";
$lang['member_purchase_date'] = "Purchase Date";
$lang['member_location'] = "Location";
$lang['member_quantity'] = "Quantity";
$lang['full_name'] = "Full Name";
$lang['last_name'] = "Last Name";
$lang['email'] = "E-mail";
$lang['role_id'] = "Role ";
$lang['member_description'] = "Description";
$lang['member_identification_code'] = "Identification Code";
$lang['dept_id'] = "Department ";
$lang['display_picture_path'] = "DP";
$lang['member_address'] = "Address";
$lang['member_city'] = "City";
$lang['member_state'] = "State";
$lang['member_zip_code'] = "Zip";
$lang['member_country'] = "Country";
$lang['member_phone'] = "Phone";
$lang['member_status'] = "Status";
$lang[''] = "";

