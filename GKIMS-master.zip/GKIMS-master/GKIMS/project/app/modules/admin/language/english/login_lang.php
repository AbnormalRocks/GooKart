<?php

/* login lang */

$lang['invalid_credential_messege'] = "<strogn>Error!</strong> Username or password is incorrect. Please try again.";
$lang['password_reset_message'] = "<strong>Success!</strong> Password reset request send to your email.";
$lang['email_invalid_message'] = "<strong>Error!</strong> This email is not associated with any account.";
$lang['sign_in'] = "Sign In";
$lang['password'] = "password";
$lang['email'] = "Email";
$lang['remember_me'] = "Remember Me";
$lang['designed_by'] = "Design by WIE Software Pvt. Ltd.";
$lang['forget_password'] = "Forgot your password?";
$lang['login'] = "Login";
$lang['first_name'] = "First Name";
$lang['last_name'] = "Last Name";
$lang['user_name'] = "User Name";
$lang['email'] = "E-mail";
$lang['password'] = "Password";
$lang['status'] = "Status";
$lang['dp_path'] = "Display Picture";
$lang['is_admin'] = "Authority";
$lang['add_page'] = "Add User";
$lang['page_form'] = "User form";
$lang['page_list'] = "User list";
$lang['department_placeholder'] = "Search User by name";
$lang['is_timesheet_required'] = "Is User timesheet atachment required?";
$lang['edit_page'] = "Edit User Profile";
$lang['user_management'] = "User Manager";
$lang['dashboard'] = "Dashboard";
$lang['title'] = "Title";
$lang['user_type'] = "User Type";
$lang['allowed_hours'] = "Allowed Hours";
$lang['allowed_vacations'] = "Allowed Vacations";
$lang['delete_selected'] = "Delete Selected";
$lang['no_record_found'] = "No Record Found";
$lang[''] = "";
$lang[''] = "";
$lang[''] = "";
$lang[''] = "";

