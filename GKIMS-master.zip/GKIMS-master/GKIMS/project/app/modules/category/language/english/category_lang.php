<?php

/* category lang */

$lang['category_name'] = "Name";

$lang['category_id'] = "ID";
$lang['category_description'] = "Description";
$lang['category_code'] = "Code";
$lang['category_status'] = "Status";
$lang['no_of items'] = "No. of Items";
$lang['add_page'] = "Add Category";
$lang['page_form'] = "Category form";
$lang['page_list'] = "Category list";
$lang['department_placeholder'] = "Search Category by name";
$lang['is_timesheet_required'] = "Is Category timesheet atachment required?";
$lang['edit_page'] = "Edit Category";
$lang['category_management'] = "Category Manager";
$lang['dashboard'] = "Dashboard";
$lang['title'] = "Title";
$lang['Category_type'] = "Category Type";
$lang['allowed_hours'] = "Allowed Hours";
$lang['allowed_vacations'] = "Allowed Vacations";
$lang['delete_selected'] = "Delete Selected";
$lang['no_record_found'] = "No Record Found";
$lang[''] = "";
$lang[''] = "";
$lang[''] = "";
$lang[''] = "";

