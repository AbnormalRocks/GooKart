<?php

/* dept lang */

$lang['dept_name'] = "Name";

$lang['dept_id'] = "ID";
$lang['dept_description'] = "Description";
$lang['dept_code'] = "Code";
$lang['dept_status'] = "Status";
$lang['no_of items'] = "No. of Items";
$lang['add_page'] = "Add Department";
$lang['page_form'] = "Department form";
$lang['page_list'] = "Department list";
$lang['department_placeholder'] = "Search Department by name";
$lang['is_timesheet_required'] = "Is Department timesheet atachment required?";
$lang['edit_page'] = "Edit Department";
$lang['dept_management'] = "Department Manager";
$lang['dashboard'] = "Dashboard";
$lang['title'] = "Title";
$lang['dept_type'] = "Department Type";
$lang['allowed_hours'] = "Allowed Hours";
$lang['allowed_vacations'] = "Allowed Vacations";
$lang['delete_selected'] = "Delete Selected";
$lang['no_record_found'] = "No Record Found";
$lang[''] = "";
$lang[''] = "";
$lang[''] = "";
$lang[''] = "";

