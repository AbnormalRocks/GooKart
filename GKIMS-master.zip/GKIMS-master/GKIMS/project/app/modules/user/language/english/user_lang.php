<?php

/* department lang */

$lang['category_name'] = "categoryname";
$lang['phone'] = "Phone Number";
$lang['first_name'] = "First Name";
$lang['last_name'] = "Last Name";
$lang['email'] = "Email Id";
$lang['password'] = "Password";
$lang['con_password'] = "Confirm Password";
$lang['department'] = "Department";
$lang['category_department'] = "Department";
$lang['role'] = "Role";
$lang['add_page'] = "Add category";
$lang['page_form'] = "category form";
$lang['page_list'] = "categorys list";
$lang['department_placeholder'] = "Search category by name";
$lang['is_timesheet_required'] = "Is category timesheet atachment required?";
$lang['edit_page'] = "Edit category";
$lang['category_management'] = "categorys Manage";
$lang['dashboard'] = "Dashboard";
$lang['title'] = "Title";
$lang['category_type'] = "category Type";
$lang['allowed_hours'] = "Allowed Hours";
$lang['allowed_vacations'] = "Allowed Vacations";

$lang[''] = "";
$lang[''] = "";
$lang[''] = "";

