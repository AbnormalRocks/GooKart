<?php

/* project lang */

$lang['add_page'] = "Add page";
$lang['page_form'] = "Report form";
$lang['page_list'] = "Report list";
$lang['auditLast_placeholder'] = "Search by Last Name";
$lang['auditStart_placeholder'] = "Search by Start Date";
$lang['auditEnd_placeholder'] = "Search by End Date";
$lang['auditAction_placeholder'] = "Search by Action";
$lang['edit_page'] = "Edit page";
$lang['report_management'] = "Reports Manager";
$lang['dashboard'] = "Dashboard";
$lang['title'] = "Title";
$lang['export_csv'] = "Export CSV";
$lang['member_name'] = "Select member to show Assigned Items";
$lang[''] = "";
$lang[''] = "";
$lang[''] = "";

