<?php

/* item lang */

$lang['item_name'] = "Name";
$lang['item_model_number'] = "Model No.";
$lang['category_id'] = "Category ID";
$lang['item_identification_key'] = "Identification Key";
$lang['item_cost_price'] = "Cost Price";
$lang['item_vendor_id'] = "Vendor ID";
$lang['item_purchase_date'] = "Purchase Date";
$lang['item_location'] = "Location";
$lang['item_quantity'] = "Quantity";
$lang['item_id'] = "ID";
$lang['item_description'] = "Description";
$lang['item_code'] = "Code";
$lang['item_status'] = "Status";
$lang['no_of items'] = "No. of Items";
$lang['add_page'] = "Add Item";
$lang['page_form'] = "Item form";
$lang['page_list'] = "Item list";
$lang['department_placeholder'] = "Search Item by name";
$lang['is_timesheet_required'] = "Is Item timesheet atachment required?";
$lang['edit_page'] = "Edit Item";
$lang['item_management'] = "Item Manager";
$lang['dashboard'] = "Dashboard";
$lang['title'] = "Title";
$lang['item_type'] = "Item Type";
$lang['allowed_hours'] = "Allowed Hours";
$lang['allowed_vacations'] = "Allowed Vacations";
$lang['delete_selected'] = "Delete Selected";
$lang['no_record_found'] = "No Record Found";
$lang['item_model_number'] = "Model No.";
$lang['category_id'] = "Category";
$lang['item_identification_key'] = "Identification Key";
$lang['item_cost_price'] = "Cost Price";
$lang['item_vendor_id'] = "Vendor ID";
$lang['item_purchase_date'] = "Purchase Date";
$lang['item_location'] = "Location";
$lang['item_quantity'] = "Quantity";
$lang['vendor_id'] = "Vendor";
$lang[''] = "";

