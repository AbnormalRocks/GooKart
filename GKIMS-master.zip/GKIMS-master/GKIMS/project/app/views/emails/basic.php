<?php 

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><meta name="viewport" content="initial-scale=1.0"><meta name="format-detection" content="telephone=no"><style type="text/css">.socialLinks {font-size: 6px;}
.socialLinks a {display: inline-block;}
.socialIcon {display: inline-block;vertical-align: top;padding-bottom: 0px;border-radius: 100%;}
table.vb-row, table.vb-content {border-collapse: separate;}
table.vb-row {border-spacing: 9px;}
table.vb-row.halfpad {border-spacing: 0;padding-left: 9px;padding-right: 9px;}
table.vb-row.fullwidth {border-spacing: 0;padding: 0;}
table.vb-container.fullwidth {padding-left: 0;padding-right: 0;}</style><style type="text/css">
    /* yahoo, hotmail */
    .ExternalClass, .ExternalClass p, .ExternalClass span, .ExternalClass font, .ExternalClass td, .ExternalClass div{ line-height: 100%; }
    .yshortcuts a{ border-bottom: none !important; }
    .vb-outer{ min-width: 0 !important; }
    .RMsgBdy, .ExternalClass{
      width: 100%;
      background-color: #3f3f3f;
      background-color: #3f3f3f}

    /* outlook */
    table{ mso-table-rspace: 0pt; mso-table-lspace: 0pt; }
    #outlook a{ padding: 0; }
    img{ outline: none; text-decoration: none; border: none; -ms-interpolation-mode: bicubic; }
    a img{ border: none; }

    @media screen and (max-device-width: 600px), screen and (max-width: 600px) {
      table.vb-container, table.vb-row{
        width: 95% !important;
      }

      .mobile-hide{ display: none !important; }
      .mobile-textcenter{ text-align: center !important; }

      .mobile-full{
        float: none !important;
        width: 100% !important;
        max-width: none !important;
        padding-right: 0 !important;
        padding-left: 0 !important;
      }
      img.mobile-full{
        width: 100% !important;
        max-width: none !important;
        height: auto !important;
      }   
    }
  </style></head><body style="margin: 0;padding: 0;background-color: #3f3f3f;color: #919191;" text="#919191" vlink="#cccccc" alink="#cccccc" bgcolor="#3f3f3f">
  <center>
  <table id="ko_titleBlock_3" style="background-color: #1f497d;" class="vb-outer" width="100%" bgcolor="#1f497d" border="0" cellpadding="0" cellspacing="0">
  <tbody>
  <tr>
  <td style="padding-left: 9px;padding-right: 9px;background-color: #1f497d;" class="vb-outer" valign="top" align="center" bgcolor="#1f497d">
        <div class="oldwebkit" style="max-width: 570px;">
        <table style="border-collapse: separate;border-spacing: 9px;padding-left: 9px;padding-right: 9px;width: 100%;max-width: 570px;background-color: #c6d9f0;" class="vb-container halfpad" width="570" bgcolor="#c6d9f0" border="0" cellpadding="0" cellspacing="9">
		<tbody>
			<tr>
				<td style="background-color: #c6d9f0; font-size: 22px; font-family: Arial, Helvetica, sans-serif; color: #3f3f3f; text-align: center;" align="center" bgcolor="#c6d9f0">
				  <span>iHour Request Alert</span>
				</td>
			</tr>
		</tbody>
		</table>
		</div>

      </td>
    </tr></tbody></table>
	<table id="ko_textBlock_4" style="background-color: #1f497d;" class="vb-outer" width="100%" bgcolor="#1f497d" border="0" cellpadding="0" cellspacing="0">
	<tbody>
	<tr>
	<td style="padding-left: 9px;padding-right: 9px;background-color: #1f497d;" class="vb-outer" valign="top" align="center" bgcolor="#1f497d">

        <div class="oldwebkit" style="max-width: 570px;">
			<table style="border-collapse: separate;border-spacing: 18px;padding-left: 0;padding-right: 0;width: 100%;max-width: 570px;background-color: #c6d9f0;" class="vb-container fullpad" width="570" bgcolor="#c6d9f0" border="0" cellpadding="0" cellspacing="18">
				<tbody>
					<tr>
						<td style="text-align: left; font-size: 13px; font-family: Arial, Helvetica, sans-serif; color: #262626;" class="long-text links-color" align="left"><p style="margin: 1em 0px;margin-top: 0px;">Dear ----,<a href="" style="color: #c0504d;text-decoration: underline;"><br></a><br data-mce-bogus="1"></p><p style="margin: 1em 0px;">Please submit your approved timesheet for following Week ---.<br data-mce-bogus="1"></p><p style="margin: 1em 0px;">Click <strong>here</strong> to fill timesheet.<br data-mce-bogus="1"></p><p style="margin: 1em 0px;"><br data-mce-bogus="1"></p><p style="margin: 1em 0px;"><br data-mce-bogus="1"></p><p style="margin: 1em 0px;">Best Regards<br data-mce-bogus="1"></p><p style="margin: 1em 0px;">Human Resource<br data-mce-bogus="1"></p><p style="margin: 1em 0px;">Company name<br data-mce-bogus="1"></p><p style="margin: 1em 0px;margin-bottom: 0px;"><br data-mce-bogus="1"></p>
						</td>
					</tr>
				</tbody>
			</table>
		</div>

      </td>
    </tr>
	</tbody>
	</table></center>

</body>
</html>
