 <footer class="footer">
            <div class="container-fluid">
                <nav class="pull-left">
                    <ul>
                        <li>
                            <a href="localhost/project/">
                                Home
                            </a>
                        </li>
                       
                        <li>
                            <a href="www.globtierinfotech.com/aboutus.htm">
                               About Us
                            </a>
                        </li>
						 <li>
                          <a href="https://www.facebook.com/globtier/"> <i class="fa fa-facebook-square"></i></a>
						  </li>
						  <li>
						  <a href="https://twitter.com/Globtier44"><i class="fa fa-twitter"></i></a>
						  </li>
						  <li>
						  <a href="https://plus.google.com/u/0/114422184026542240552"><i class="fa fa-google-plus-square"></i></a>
                        </li>
                        
                    </ul>
                </nav>
                <p class="copyright pull-right">
                    &copy; 2016 <a href="http://www.globtierinfotech.com">Globtier Infotech PVT LTD.</a>, made by Kartikeya Misra under supervision of Mr. Abhay Pratap Singh.
                </p>
            </div>
        </footer>
		                        