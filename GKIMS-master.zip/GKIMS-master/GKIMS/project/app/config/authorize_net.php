<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

// Authorize.net Account Info
$config['api_login_id'] = '25wSWp3J6';
//$config['api_login_id'] = '8vc69VDEJH98';
$config['api_transaction_key'] = '92ar653YEBXPw6ws';
//$config['api_transaction_key'] = '2Qq4L4547Ksn2sTb';
$config['api_url'] = 'https://test.authorize.net/gateway/transact.dll'; // TEST URL
//$config['api_url'] = 'https://secure.authorize.net/gateway/transact.dll'; // PRODUCTION URL

/* EOF */